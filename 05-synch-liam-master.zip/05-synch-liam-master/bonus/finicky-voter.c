/*
 * 
 *
 * CS 441/541: Finicky Voter (Bonus Version)
 *
 */
#include "finicky-voter.h"

int main(int argc, char * argv[]) {

    return 0;
}
