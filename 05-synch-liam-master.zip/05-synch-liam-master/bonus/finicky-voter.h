/*
 * 
 *
 * CS 441/541: Finicky Voter (Bonus Version)
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>
#include "../lib/semaphore_support.h"

/*****************************
 * Defines
 *****************************/

/*****************************
 * Structures
 *****************************/


/*****************************
 * Global Variables
 *****************************/

/*****************************
 * Function Declarations
 *****************************/

